<?php

echo view('layout/v_head_auth');
echo view('layout/v_header_auth');
echo view('layout/v_nav_auth');
echo view('layout/v_content_auth');
echo view('layout/v_footer_auth');
