<?php
if ($isi_landing) {
    echo view($isi_landing);
}
