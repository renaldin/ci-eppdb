<?php

echo view('layout/v_head_landing');
echo view('layout/v_header_landing');
echo view('layout/v_nav_landing');
echo view('layout/v_content_landing');
echo view('layout/v_footer_landing');
