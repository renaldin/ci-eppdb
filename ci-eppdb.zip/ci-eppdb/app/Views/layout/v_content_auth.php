<?php
if ($isi_auth) {
    echo view($isi_auth);
}
